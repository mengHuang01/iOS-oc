//
//  MHScrollView.h
//  scrollView无限轮播
//
//  Created by qfh on 16/5/9.
//  Copyright © 2016年 qiufuhe. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef enum{
    left = 0,
    right = 1
}myDirection; //无限循环的方向



@interface MHScrollView : UIView

//定义图片数组
@property (nonatomic, strong) NSArray *images;

//定义循环方向
@property (nonatomic, assign) myDirection scrollDirection;

//定义定时器时间
@property (nonatomic, assign) CGFloat animationTime;

//停止定时器 并销毁定时器
- (void)stopTimer;

//类方法，创建scrollview
+ (instancetype)scrollView;


@end
