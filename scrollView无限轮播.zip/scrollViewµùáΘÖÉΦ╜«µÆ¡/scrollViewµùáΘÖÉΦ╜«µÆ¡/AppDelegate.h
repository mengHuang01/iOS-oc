//
//  AppDelegate.h
//  scrollView无限轮播
//
//  Created by qfh on 16/5/9.
//  Copyright © 2016年 qiufuhe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

