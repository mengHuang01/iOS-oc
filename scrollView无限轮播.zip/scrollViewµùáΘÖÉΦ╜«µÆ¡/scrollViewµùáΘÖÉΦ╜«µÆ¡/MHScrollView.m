//
//  MHScrollView.m
//  scrollView无限轮播
//
//  Created by qfh on 16/5/9.
//  Copyright © 2016年 qiufuhe. All rights reserved.
//

#import "MHScrollView.h"

@interface MHScrollView ()<UIScrollViewDelegate>

//定义scollview
@property (nonatomic, weak) UIScrollView *scrollView;
//定义pageControl
@property (nonatomic, weak) UIPageControl *pageControl;
//定义定时器
@property (nonatomic, strong) NSTimer *timer;


@end


@implementation MHScrollView

#pragma mark- 定时器


/**
 *  启动定时器,没有给定时器定时时间赋值，则不开启定时器
 */
- (void)startTimer
{
    if (self.animationTime) {
        self.timer = [NSTimer timerWithTimeInterval:self.animationTime target:self selector:@selector(nextPage) userInfo:nil repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
    }
   
}
/**
 *  停止定时,并释放定时器
 */
- (void)stopTimer
{
    [self.timer invalidate];
    self.timer = nil;
    
}

/**
 *  定时器定时方法
 */
- (void)nextPage
{
    
     CGFloat scrollW = self.scrollView.frame.size.width;
    

    if (self.scrollDirection == right) {
        
        CGFloat sizeX = self.scrollView.contentOffset.x;
        
       CGPoint oldSize = CGPointMake(sizeX + scrollW, 0);
        
        if (sizeX >= (self.images.count + 1) *  scrollW) {
            self.scrollView.contentOffset = CGPointMake(scrollW, 0);
            [self.timer fire];
        }else
        {
            [self.scrollView setContentOffset:oldSize animated:YES];

        }
        
    }else if (self.scrollDirection == left)
    {
        CGFloat sizeX = self.scrollView.contentOffset.x;
        
        CGPoint oldSize = CGPointMake(sizeX - scrollW, 0);
        
        if (sizeX  < scrollW ) {
            self.scrollView.contentOffset = CGPointMake(scrollW * self.images.count  , 0);
            [self.timer fire];
        }else
        {
            [self.scrollView setContentOffset:oldSize animated:YES];
            
        }
    }
}

/**
 *重写animationTime，并开启定时器
 *
 *  @param animationTime 定时器时间
 */
- (void)setAnimationTime:(CGFloat)animationTime
{
    _animationTime = animationTime;
    [self startTimer];
    
}


#pragma mark- 页面初始化

/**
 *  设置scrollview
 */
- (void)setUpScrollView
{
    CGFloat imgH = self.scrollView.frame.size.height;
    CGFloat imgW = self.scrollView.frame.size.width;
    
    for (int i = 0; i < self.images.count + 2; i++)
    {
        
        CGFloat imgX = i * imgW;
        CGFloat imgY = 0;
        
        UIImageView *imgView = [[UIImageView alloc]init];
        
        if (i == 0) {
            
            imgView.frame = CGRectMake(0, imgY, imgW, imgH);
            imgView.image = [UIImage imageNamed:self.images[self.images.count - 1]];
        }else if (i == self.images.count + 1)
        {
            imgView.frame = CGRectMake(imgW * (self.images.count +1), imgY, imgW, imgH);
            imgView.image = [UIImage imageNamed:self.images[0]];
        }else
        {
           
            imgView.frame = CGRectMake(imgX, imgY, imgW, imgH);
            imgView.image = [UIImage imageNamed:self.images[i - 1]];
        
        }
        
        [self.scrollView addSubview:imgView];
        
        
    }
    
    self.scrollView.contentSize = CGSizeMake((self.images.count + 2) * imgW, imgH);
    self.scrollView.contentOffset = CGPointMake(self.scrollView.frame.size.width, 0);
    
    self.scrollView.pagingEnabled = YES;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.delegate = self;
    
   
    
}
/**
 *  设置pageControl
 */
- (void)setUpPageControl
{
    self.pageControl.numberOfPages = self.images.count;
    self.pageControl.pageIndicatorTintColor = [UIColor redColor];
    self.pageControl.currentPageIndicatorTintColor = [UIColor blueColor];
    self.pageControl.multipleTouchEnabled = YES;
}

#pragma mark- scrollView代理

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self stopTimer];
}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    [self startTimer];
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat sizeX = self.scrollView.contentOffset.x;
    CGFloat scrollW = self.scrollView.frame.size.width;
    
    
    NSInteger pageMove = sizeX / scrollW;
//    NSLog(@"%ld  %lf", pageMove, sizeX);
    
    if (pageMove >= self.images.count + 1) {
        
        self.scrollView.contentOffset = CGPointMake(scrollW, 0);
    }
    
    if (sizeX <= 0) {
        self.scrollView.contentOffset = CGPointMake(scrollW * self.images.count , 0);
    }
    
    
    
    NSInteger pageNum = (sizeX + scrollW * 0.5) / scrollW;
    
   
    if (sizeX <= scrollW * 0.5 ) {
        pageNum = self.images.count;
    } else if (pageNum >self.images.count)
    {
        pageNum = 1;
    }
    
     pageNum = pageNum - 1;
    
    self.pageControl.currentPage = pageNum;
}

#pragma mark- init重构

/**
 *  创建scrollView，pageControl
 *
 *
 */
- (instancetype)init
{
    if (self = [super init]) {
        
        UIScrollView *scrollView = [[UIScrollView alloc]init];
        
        _scrollView = scrollView;
        
        [self addSubview:scrollView];
        
        UIPageControl *pageControl = [[UIPageControl alloc]init];
        
        _pageControl = pageControl;
        
        [self addSubview:pageControl];

    }
    return self;
}


+ (instancetype)scrollView
{
    return [[self alloc]init];
}



#pragma mark- 加约束
- (void)layoutSubviews
{
    [super layoutSubviews];
    
    //关闭Autoresizing
    self.scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    
    NSArray *HConsy = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-(num)-[scrollView]-(num)-|" options:NSLayoutFormatAlignAllTop metrics:@{@"num":@0} views:@{@"scrollView":self.scrollView}];
    
    NSArray *WConsy = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-(num)-[scrollView]-(num)-|" options:(NSLayoutFormatAlignAllTop) metrics:@{@"num":@0} views:@{@"scrollView":self.scrollView}];
    
    [self addConstraints:HConsy];
    [self addConstraints:WConsy];
    
    [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-(num)-[scrollView]-(num)-|" options:NSLayoutFormatAlignAllTop metrics:@{@"num":@0} views:@{@"scrollView":self.scrollView}];

    
    self.pageControl.translatesAutoresizingMaskIntoConstraints = NO;
    NSArray *pageConsy =  [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-(num)-[scrollView]-(num)-|" options:NSLayoutFormatAlignAllTop metrics:@{@"num":@0} views:@{@"scrollView":self.pageControl}];
    
    NSArray *pageH = [NSLayoutConstraint constraintsWithVisualFormat:@"V:[view(50)]-(num)-|" options:NSLayoutFormatAlignAllTop metrics:@{@"num":@0} views:@{@"view":self.pageControl}];
    
    
    
    [self addConstraints:pageConsy];
    [self addConstraints:pageH];
    
    
    [self setUpScrollView];
    [self setUpPageControl];

}



@end
