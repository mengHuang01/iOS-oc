//
//  ViewController.m
//  scrollView无限轮播
//
//  Created by qfh on 16/5/9.
//  Copyright © 2016年 qiufuhe. All rights reserved.
//

#import "ViewController.h"
#import "MHScrollView.h"

#define IMG_NUMBER 9

@interface ViewController ()

@property (nonatomic, strong) NSArray *imgArray;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
//    MHScrollView *scrollView= [[MHScrollView alloc]init];
    
    MHScrollView *scrollView = [MHScrollView scrollView];
//      设置frame的方式创建scrollViwe
//    scrollView.frame = CGRectMake(0, 0, 300, 150);
//    scrollView.center = self.view.center;
    
    
    
    //设置图片数组
    scrollView.images = self.imgArray;
    //设置自动滚动方向
    scrollView.scrollDirection = right;
    //设置定时器时间，若果没有赋值，不开启自动滚动
    scrollView.animationTime = 2.0;
    //若使用自动布局，得先添加到父控件
    [self.view addSubview:scrollView];

    
    //自动布局创建scrollView
    scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    NSArray *HConsy = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-(num)-[scrollView]-(num)-|" options:NSLayoutFormatAlignAllTop metrics:@{@"num":@10} views:@{@"scrollView":scrollView}];
    
    NSArray *WConsy = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-(num)-[scrollView]-(num)-|" options:(NSLayoutFormatAlignAllTop) metrics:@{@"num":@10} views:@{@"scrollView":scrollView}];
    
    [self.view addConstraints:HConsy];
    [self.view addConstraints:WConsy];
    

    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark- 懒加载

- (NSArray *)imgArray
{
    if (!_imgArray) {
        NSMutableArray *array = [NSMutableArray array];
        for (int i = 0; i < IMG_NUMBER; i++)
        {
            NSString *img = [NSString stringWithFormat:@"%d",i];
            [array addObject:img];
        }
        _imgArray = array;
    }
    return _imgArray;
}

@end
